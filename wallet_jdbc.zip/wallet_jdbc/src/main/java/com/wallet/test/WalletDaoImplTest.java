package com.wallet.test;

import static org.junit.Assert.*;

import java.time.LocalDate;
import org.junit.Test;

import com.wallet.bean.Account;
import com.wallet.bean.Customer;
import com.wallet.dao.WalletDao;
import com.wallet.dao.WalletDaoImpl;
import com.wallet.exception.WalletException;

public class WalletDaoImplTest {

	WalletDao wDao = new WalletDaoImpl();
	
	@Test
	public void testCreateAccount() throws WalletException {
	  
		String account1 = wDao.createAccount(new Customer("Virat","Delhi","31","8574915365","iamVirat"), new Account("current","85000.50"));
		String account2 = wDao.createAccount(new Customer("Tom","Bangalore","24","8574968574","tom12"), new Account("savings","2500.65"));
		
		
	    assertEquals(true,wDao.checkAccountExist(account1));
	    assertEquals(true,wDao.checkAccountExist(account2));
		
	}

	@Test
	public void testShowBalance() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Harry","Chennai","29","9685748695","potter"), new Account("current","3520.65"));
		assertEquals("3520.65", wDao.showBalance(account1));
		
	}

	@Test
	public void testDeposit() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Mark","Mumbai","34","8578768574","marky"), new Account("savings","8600.65"));
		
		assertEquals("8600.65", wDao.showBalance(account1));
		
		String newBalance = wDao.deposit(account1, "400");
		
		assertEquals(newBalance, wDao.showBalance(account1));
	}

	@Test
	public void testWithdraw() throws WalletException {
		String account1 = wDao.createAccount(new Customer("Bill","Mipl","24","8574965574","Bill"), new Account("current","25000.65"));
		
		assertEquals("25000.65", wDao.showBalance(account1));
		
		String newBalance = wDao.withdraw(account1, "16000");
		
		assertEquals(newBalance, wDao.showBalance(account1));
	}

	@Test
	public void testFundTransfer() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Virat","Delhi","31","8574915365","iamVirat"), new Account("current","85000.50"));
		String account2 = wDao.createAccount(new Customer("Tom","Bangalore","24","8574968574","tom12"), new Account("savings","2500.65"));
		
		
	    assertEquals(true,wDao.checkAccountExist(account1));
	    assertEquals(true,wDao.checkAccountExist(account2));
	    
	    String senderBalance = wDao.fundTransfer(account1, "65000", account2);
	    
	    assertEquals(senderBalance, wDao.showBalance(account1));
	    assertEquals("67500.65", wDao.showBalance(account2));
	}

	@Test
	public void testPrintTransaction() throws WalletException {
		
		String account1 = wDao.createAccount(new Customer("Virat","Delhi","31","8574915365","iamVirat"), new Account("current","85000.50"));
		String account2 = wDao.createAccount(new Customer("Mark","Mumbai","34","8578768574","marky"), new Account("savings","8600.65"));
	
		String newBalance = wDao.deposit(account1, "400");
		wDao.transaction("deposit", LocalDate.now(), account1, account1, "success","400");
		
		assertEquals(newBalance, wDao.showBalance(account1));
		
		String senderBalance = wDao.fundTransfer(account1, "65000", account2);
		wDao.transaction("transfer", LocalDate.now(), account1, account2, "success","65000");
		
		assertEquals(senderBalance, wDao.showBalance(account1));
	    
	    assertEquals(1,wDao.printTransaction(account1).size());
	    assertEquals(0,wDao.printTransaction(account2).size());
	}

}
